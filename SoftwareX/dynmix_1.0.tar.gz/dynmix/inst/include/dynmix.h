#ifndef dynmix
#define dynmix

#define ARMA_NO_DEBUG

#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace std;
using namespace arma;
using namespace Rcpp;

#endif
